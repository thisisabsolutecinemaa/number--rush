"""Deterministic starter catalog for NUMBER RUSH. All values are fictional game items."""
from sqlalchemy import select
from .models import Plate

COUNTRIES = {
    "Украина": {"flag": "🇺🇦", "prefix": "UA", "letters": ["AA", "KA", "BC", "AX", "BI", "AE", "AP", "BH", "CE", "CH"]},
    "Китай": {"flag": "🇨🇳", "prefix": "CN", "letters": ["京A", "沪B", "粤C", "浙D", "苏E", "鲁F", "川G", "鄂H", "湘J"]},
    "Россия": {"flag": "🇷🇺", "prefix": "RU", "letters": ["АА", "ВВ", "ЕК", "КК", "ММ", "ОО", "РР", "СС", "ТТ", "ХХ"]},
    "Европа": {"flag": "🇪🇺", "prefix": "EU", "letters": ["D", "F", "I", "E", "PL", "NL", "CZ", "AT", "BE", "LT"]},
}

RARITIES = ["Обычный", "Необычный", "Редкий", "Эпический", "Легендарный", "Мифический", "Секретный", "Абсолют"]
SPECIALS = ["Дипломатический", "Военный", "Государственный", "Такси", "Транзитный", "Временный", "Исторический", "Коллекционный"]
LUCKY = [
    ("Блатной", ["001", "007", "010", "100", "111", "222", "333", "444", "555", "777", "888", "999"]),
    ("Почти блатной", ["011", "022", "077", "099", "101", "110", "121", "123", "202", "303", "505", "707", "808", "909"]),
]

async def seed_catalog(db):
    existing = await db.scalar(select(Plate.id).limit(1))
    if existing:
        return
    rows = []
    for country, meta in COUNTRIES.items():
        letters = meta["letters"]
        # Regular and special series across every supported country.
        for rarity_idx, rarity in enumerate(RARITIES):
            for n in range(1, 13):
                code = f"{letters[(n + rarity_idx) % len(letters)]} {n*37:04d} {letters[(n*3) % len(letters)]}"
                rows.append(Plate(code=code, region=country, category="Стандартный", rarity=rarity,
                                  talisman=rarity_idx >= 3, buff=(
                                      {"price_luck": 0.01 * (rarity_idx + 1), "description": "Немного повышает шанс получить более дорогую оценку"}
                                      if rarity_idx >= 3 else {})))
        for category_idx, category in enumerate(SPECIALS):
            for n in range(1, 9):
                rarity = RARITIES[min(7, 2 + category_idx // 2 + (n % 3))]
                code = f"{meta['prefix']} {category_idx+1}{n:03d} {letters[n % len(letters)]}"
                rows.append(Plate(code=code, region=country, category=category, rarity=rarity, talisman=True,
                                  buff={"price_luck": round(0.02 + 0.01 * (category_idx % 4), 3),
                                        "description": "Бонус к удаче при оценке стоимости"}))
        for category, patterns in LUCKY:
            for n, pattern in enumerate(patterns):
                rarity = "Легендарный" if category == "Блатной" and pattern in {"001", "007", "777", "888", "999"} else "Эпический"
                rows.append(Plate(code=f"{letters[n % len(letters)]} {pattern} {letters[(n+2) % len(letters)]}",
                                  region=country, category=category, rarity=rarity, talisman=True,
                                  buff={"price_luck": 0.12 if category == "Блатной" else 0.06,
                                        "description": "Повышает удачу при оценке цены найденных номеров"}))
    db.add_all(rows)
    await db.flush()

import React from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

declare global { interface Window { Telegram?: any } }
const tg = window.Telegram?.WebApp;
tg?.ready(); tg?.expand();
const API = import.meta.env.VITE_API_URL || '';

function App() {
  const [balance,setBalance] = React.useState<number>(100000);
  const [result,setResult] = React.useState<any>(null);
  const [items,setItems] = React.useState<any[]>([]);
  const [tab,setTab] = React.useState<'spin'|'collection'>('spin');
  const [busy,setBusy] = React.useState(false);
  const [error,setError] = React.useState('');
  const initData = tg?.initData || '';
  const headers = {'X-Telegram-Init-Data':initData};
  async function loadInventory() {
    try { const r=await fetch(`${API}/api/inventory`,{headers}); if(r.ok) setItems(await r.json()); }
    catch { /* API may not be deployed yet */ }
  }
  React.useEffect(()=>{ loadInventory(); },[]);
  async function spin() {
    setBusy(true); setError(''); setResult(null);
    try {
      const res = await fetch(`${API}/api/spin`, {method:'POST',headers});
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Ошибка прокрутки');
      setResult(data); setBalance(data.balance); await loadInventory(); tg?.HapticFeedback?.notificationOccurred('success');
    } catch(e:any) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function equip(itemId:number) {
    try {
      const r=await fetch(`${API}/api/equip`,{method:'POST',headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId})});
      const data=await r.json(); if(!r.ok) throw new Error(data.detail||'Не удалось экипировать'); await loadInventory();
    } catch(e:any) { setError(e.message); }
  }
  return <main>
    <header><div className="mark">NR</div><div><b>NUMBER RUSH</b><small>PLATE COLLECTION</small></div><span className="avatar">🚘</span></header>
    <section className="wallet"><small>ВАШ БАЛАНС</small><strong>{balance.toLocaleString('ru-RU')} ₽</strong><span>Игровые рубли</span></section>
    <div className="tabs"><button className={tab==='spin'?'active':''} onClick={()=>setTab('spin')}>🎰 Крутка</button><button className={tab==='collection'?'active':''} onClick={()=>{setTab('collection');loadInventory()}}>🎒 Коллекция ({items.length})</button></div>
    {tab==='spin' ? <section className="hero">
      <div className="eyebrow">COLLECT • UPGRADE • TRADE</div><h1>Открой свой<br/>номер.</h1>
      <p>Собирай номера Украины, Китая, России и Европы — обычные, дипломатические, военные, блатные и коллекционные.</p>
      <div className="plate"><span>🇺🇦</span><b>AA 0000 XX</b><i>UA</i></div>
      <button disabled={busy} onClick={spin}>{busy?'ОТКРЫВАЕМ...':'ПРОКРУТИТЬ · 5 000 ₽'}</button><small className="muted">10 прокруток — 50 000 ₽</small>
      {error && <p className="error">{error}</p>}
      {result && <div className="drop"><small>ВАШ ВЫПАВШИЙ НОМЕР</small><h2>{result.code}</h2><b>{result.rarity}</b><p>{result.region} · {result.category}</p>{result.talisman&&<p>✨ Можно экипировать как талисман</p>}</div>}
    </section> : <section className="hero"><div className="eyebrow">YOUR GARAGE</div><h1>Коллекция</h1><p>Особые номера могут стать талисманами. Экипируй по одному предмету каждой высокой редкости.</p>
      {items.length===0?<p>Пока номеров нет. Сделай первую прокрутку!</p>:<div className="inventory">{items.map(item=><article className="item" key={item.item_id}><div className="itemtop"><b>{item.code}</b><span>{item.region}</span></div><strong>{item.rarity}</strong><p>{item.category} · оценка {Number(item.estimated_value).toLocaleString('ru-RU')} ₽</p>{item.buff?.price_luck>0&&<small>🍀 Удача цены +{Math.round(item.buff.price_luck*100)}%</small>}{item.equipped?<small className="equipped">✓ Экипирован</small>:item.talisman&&['Эпический','Легендарный','Мифический','Секретный','Абсолют'].includes(item.rarity)?<button onClick={()=>equip(item.item_id)}>Экипировать талисман</button>:null}</article>)}</div>}
      {error&&<p className="error">{error}</p>}
    </section>}
    <nav><span>🚘<small>NUMBER RUSH</small></span><span>🍀<small>Талисманы</small></span><span>🏆<small>Достижения скоро</small></span></nav>
  </main>
}
createRoot(document.getElementById('root')!).render(<App/>);
